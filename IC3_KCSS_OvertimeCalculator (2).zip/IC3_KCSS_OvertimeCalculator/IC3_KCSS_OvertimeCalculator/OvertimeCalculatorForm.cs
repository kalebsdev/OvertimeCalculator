﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IC3_KCSS_OvertimeCalculator
{
    public partial class OvertimeCalculatorForm : Form
    {
        public OvertimeCalculatorForm()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            hoursWorkedTextBox.Clear();
            categoryLabel.Text = "";
            hoursWorkedTextBox.Focus();
            //I hope this works.
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Preparation Data Dictionary
            double hoursWorked;
            string category = "";
            //Read from:
            hoursWorked = Convert.ToDouble(hoursWorkedTextBox.Text);
            //if statement
            if (hoursWorked >= 0 && hoursWorked <= 40)
            {
                // == >= <= !=
                category = ("Regular");
                categoryLabel.ForeColor = Color.Green;
            }
            else if (hoursWorked > 40 && hoursWorked <= 168)
            {
                category = ("Overtime");
                categoryLabel.ForeColor = Color.Red;
            }

            else
            {
                category = ("Error");
                categoryLabel.ForeColor = Color.Red;

            }

            //display to label
            categoryLabel.Text = category;
            //Hokus-Pokus here is my Focus
            hoursWorkedTextBox.Focus();
            hoursWorkedTextBox.SelectAll();

        }
    }
}
